﻿namespace TieFighter.Areas.Admin.Models.JsViewModels
{
    public class JsExists : JsDefault
    {
        public bool Exists { get; set; }
    }
}
