﻿using System;
using System.Collections.Generic;

namespace TieFighter.Areas.Admin.Models.JsViewModels
{
    public class JsResults : JsDefault
    {
        public IList<Object> Results { get; set; }
    }
}
