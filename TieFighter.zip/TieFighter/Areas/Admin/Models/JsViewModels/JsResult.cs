﻿namespace TieFighter.Areas.Admin.Models.JsViewModels
{
    public class JsResult : JsDefault
    {
        public object Result { get; set; }
    }
}
