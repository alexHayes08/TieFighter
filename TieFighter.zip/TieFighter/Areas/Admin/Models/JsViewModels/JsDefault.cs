﻿namespace TieFighter.Areas.Admin.Models.JsViewModels
{
    public class JsDefault
    {
        public string Error { get; set; }
        public string Message { get; set; }
        public bool Succeeded { get; set; }
    }
}
