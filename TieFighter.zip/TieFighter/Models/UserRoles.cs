﻿using System;

namespace TieFighter.Models
{
    [Flags]
    public enum UserRoles
    {
        Registered = 0,
        Admin = 1
    }
}
