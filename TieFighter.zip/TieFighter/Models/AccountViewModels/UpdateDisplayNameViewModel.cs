﻿namespace TieFighter.Models.AccountViewModels
{
    public class UpdateDisplayNameViewModel
    {
        public string DisplayName { get; set; }
    }
}
