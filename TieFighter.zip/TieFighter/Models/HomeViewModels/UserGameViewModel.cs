﻿using System;

namespace TieFighter.Models.HomeViewModels
{
    public class UserGameViewModel
    {
        public double DisplayLevel { get; set; }
        public string DisplayName { get; set; }
        public string Email { get; set; }
        public string Thumbnail { get; set; }
        public string Uid { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}
