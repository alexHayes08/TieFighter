﻿namespace TieFighter.Models.GameViewModals
{
    public class GameTitleViewModal
    {
        public string Title { get; set; }
        public bool IsReleased { get; set; }
        public string CoverPicture { get; set; }
        public string GameUrl { get; set; }
        public string Description { get; set; }
    }
}
