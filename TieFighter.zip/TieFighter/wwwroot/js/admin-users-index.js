﻿$(function () {
    var datatable = setupDataTable("#usersTable", "#selectAll", "#deleteSelected");
});