﻿$(function () {
    var datatable = setupDataTable("#toursTable", "#selectAll", "#deleteSelected");
});