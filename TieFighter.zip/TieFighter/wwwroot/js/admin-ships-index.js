﻿//$(function () {
//    var $table = setupDataTable("#shipsTable", "#selectAll", "#deleteSelected");
//});